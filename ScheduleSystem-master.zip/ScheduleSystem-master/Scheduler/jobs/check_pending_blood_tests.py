from datetime import datetime, timedelta

from common import requests_commons

__db_base_url = 'http://127.0.0.1:5002'
__api_base_url = 'http://127.0.0.1:5001'


def notify_blood_tests_pending():
    prescriptions = requests_commons.get_and_check(f'{__db_base_url}/get_all_prescriptions').json()
    for prescription in prescriptions:
        # get medication-blood test
        medication_blood_tests = requests_commons.get_and_check(f'{__db_base_url}/get_medication_blood_tests/{prescription["medication_name"]}').json()

        # get patient-blood test
        patient_blood_tests = requests_commons.get_and_check(f'{__db_base_url}/get_patient_blood_tests/{prescription["patient_nhs_number"]}').json()

        # check if patient blood tests are in line with medication-blood test for each prescription
        for medication_blood_test in medication_blood_tests:
            last_date_tested = __get_last_date_tested(patient_blood_tests, medication_blood_test['blood_test'])
            if last_date_tested == datetime.min or __test_is_pending(last_date_tested, medication_blood_test['frequency_days']):
                __notify(prescription["patient_nhs_number"], medication_blood_test['blood_test'])


def __get_last_date_tested(patient_blood_tests: dict, blood_test: dict) -> datetime:
    last_date_tested = datetime.min
    for patient_blood_test in patient_blood_tests:
        if patient_blood_test['blood_test'] == blood_test:
            date_taken = datetime.fromisoformat(patient_blood_test['date_taken'])
            if last_date_tested < date_taken:
                last_date_tested = date_taken

    return last_date_tested


def __test_is_pending(last_date_tested: datetime, frequency_days: int) -> bool:
    current_date = datetime.now()
    test_due_date = last_date_tested + timedelta(days=frequency_days)
    return current_date > test_due_date


def __notify(nhs_number: int, blood_test: str):
    patient_gp = requests_commons.get_and_check(f'{__db_base_url}/get_patient_general_practice/{nhs_number}').json()
    gp = requests_commons.get_and_check(f'{__db_base_url}/get_general_practice/{patient_gp["general_practice"]}').json()
    patient = requests_commons.get_and_check(f'{__db_base_url}/get_patient//{nhs_number}').json()

    notifications_data = {
        'general_practice_name': gp['name'],
        'general_practice_email': gp['email'],
        'blood_test_type': blood_test,
        'patient_name': patient['full_name'],
        'patient_email': patient['email'],
        'patient_phone_number': patient['phone_number'],
    }
    requests_commons.post_and_check(f'{__api_base_url}/notify_blood_test', notifications_data)
    pass
